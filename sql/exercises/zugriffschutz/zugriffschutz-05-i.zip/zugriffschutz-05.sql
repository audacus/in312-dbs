-- sql system/hftadmin

-- materialized views
-- head
create materialized view head as
    select
        f.bezeichner,
        p.name,
        p.vorname
    from vereinuser.funktionsbesetzung fb
    left join vereinuser.funktion f on fb.funkid = f.funkid
    left join vereinuser.person p on fb.persid = p.persid
    where
        fb.ruecktritt is null
        or
        fb.ruecktritt > current_date;

-- sponsors
create materialized view sponsors as
    select
        s.name,
        s.ort
    from vereinuser.sponsor s;

-- events
create materialized view events as
    select
        e.bezeichner,
        e.ort,
        e.datum
    from vereinuser.anlass e;

-- roles
-- world
create role world; -- öffentlichkeit
grant connect to world;
grant select on head to world;
grant select on sponsors to world;
grant select on events to world;

-- head
create role head; -- vorstand
grant world to head;
grant select on vereinuser.anlass to head;
grant select on vereinuser.funktion to head;
grant select on vereinuser.funktionsbesetzung to head;
grant select on vereinuser.person to head;
grant select on vereinuser.spende to head;
grant select on vereinuser.sponsor to head;
grant select on vereinuser.sponsorenkontakt to head;
grant select on vereinuser.status to head;
grant select on vereinuser.teilnehmer to head;

-- secretary
create role secretary; -- sekretariat
grant world to secretary;
grant select, insert, update, delete on vereinuser.anlass to secretary;
grant select, insert, update, delete on vereinuser.funktion to secretary;
grant select, insert, update, delete on vereinuser.funktionsbesetzung to secretary;
grant select, insert, update, delete on vereinuser.person to secretary;
grant select, insert, update, delete on vereinuser.status to secretary;
grant select, insert, update, delete on vereinuser.teilnehmer to secretary;

-- finances
create role finances; -- finanzen
grant world to finances;
grant head to finances;
grant select, insert, update, delete on vereinuser.spende to finances;
grant select, insert, update, delete on vereinuser.sponsor to finances;
grant select, insert, update, delete on vereinuser.sponsorenkontakt to finances;
grant select, update (bemerkungen) on vereinuser.person to finances;

-- users
-- anyobody / öffentlichkeit
create user anyobody identified by password;
grant world to anyobody;

-- lca / leo cadola
create user lca identified by password;
grant secretary to lca;

-- dme / dominik meyer
create user dme identified by password;
grant head, finances to dme;

-- bbr / beni bregger
create user bbr identified by password;
grant head, finances to bbr;

-- rgr / romy gruber
create user rgr identified by password;
grant head to rgr;

-- pme / petra meyer
create user pme identified by password;
grant head to pme;

-- owe / otto wendel
create user owe identified by password;
grant head to owe;

-- alter own data
-- add additional column with username
alter table vereinuser.person
    add benutzername char(30);

-- add username for all person
update vereinuser.person
    set benutzername = lower(substr(vorname, 1, 1) || substr(name, 1, 2));

-- create dynamic view
create materialized view myperson as
    select
        p.*,
        s.bezeichner status
    from vereinuser.person p
    left join vereinuser.status s on p.statid = s.statid
    where p.benutzername = USER;

-- create role
create role member; -- vereinsmitglied
grant world to member;
grant select on myperson to member;

-- create users
create user uni identified by password;
create user mta identified by password;
create user klu identified by password;
create user bfr identified by password;
create user fhu identified by password;
create user sba identified by password;

---

-- revert all
-- alter own data
alter table vereinuser.person
    drop column benutzername;
drop materialized view myperson;
drop role member;
drop user uni;
drop user mta;
drop user klu;
drop user bfr;
drop user fhu;
drop user sba;

-- users
drop user anyobody;
drop user lca;
drop user dme;
drop user bbr;
drop user rgr;
drop user pme;
drop user owe;

-- roles
drop role world;
drop role head;
drop role secretary;
drop role finances;

-- views
drop materialized view head;
drop materialized view sponsors;
drop materialized view events;
